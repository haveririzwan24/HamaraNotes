package com.hamaranotes.app;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.*;
import android.os.ParcelFileDescriptor;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class EditPdfActivity extends Activity {
    private PdfRenderer renderer; private ParcelFileDescriptor pfd; private Uri inputUri;
    private EditorView editor; private int pageIndex=0; private TextView pageLabel;
    @Override public void onCreate(Bundle b){ super.onCreate(b); inputUri=getIntent().getParcelableExtra("uri"); if(inputUri==null){finish();return;}
        try{pfd=getContentResolver().openFileDescriptor(inputUri,"r");renderer=new PdfRenderer(pfd);}catch(Exception e){toast("Could not open PDF");finish();return;} buildUi();showPage(0); }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(246,244,250));
        TextView title=new TextView(this);title.setText("✨ PDF Designer");title.setTextColor(Color.WHITE);title.setTextSize(19);title.setTypeface(null,1);title.setPadding(18,14,18,14);title.setBackgroundColor(Color.rgb(103,80,164));root.addView(title);
        HorizontalScrollView hs=new HorizontalScrollView(this); LinearLayout tools=new LinearLayout(this);tools.setPadding(8,7,8,7);tools.setOrientation(LinearLayout.HORIZONTAL);
        Button pen=tool("✏️ Pen"), high=tool("🖍 Highlight"), text=tool("T Text"), rect=tool("▭ Shape"), undo=tool("↶ Undo"), redo=tool("↷ Redo"), clear=tool("🧹 Clear"), save=tool("💾 Save");
        for(Button b:new Button[]{pen,high,text,rect,undo,redo,clear,save})tools.addView(b);hs.addView(tools);root.addView(hs);
        LinearLayout colors=new LinearLayout(this);colors.setPadding(10,2,10,6); colors.addView(label("Color"));
        int[] cs={0xFF6750A4,0xFF1565C0,0xFF00897B,0xFFE65100,0xFFD81B60,0xFF212121}; for(int c:cs){Button cb=new Button(this);cb.setText("●");cb.setTextColor(c);cb.setTextSize(20);cb.setMinWidth(48);cb.setOnClickListener(v->{editor.color=c;editor.mode=EditorView.PEN;});colors.addView(cb);}
        Button plus=tool("＋ Size"), minus=tool("− Size");plus.setOnClickListener(v->{editor.width=Math.min(30,editor.width+3);});minus.setOnClickListener(v->{editor.width=Math.max(2,editor.width-3);});colors.addView(plus);colors.addView(minus);root.addView(colors);
        LinearLayout nav=new LinearLayout(this);Button prev=tool("‹");Button next=tool("›");pageLabel=new TextView(this);pageLabel.setGravity(Gravity.CENTER);nav.addView(prev,new LinearLayout.LayoutParams(0,-2,1));nav.addView(pageLabel,new LinearLayout.LayoutParams(0,-2,2));nav.addView(next,new LinearLayout.LayoutParams(0,-2,1));root.addView(nav);
        editor=new EditorView();root.addView(editor,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        pen.setOnClickListener(v->{editor.mode=EditorView.PEN;});high.setOnClickListener(v->{editor.mode=EditorView.HIGHLIGHT;});text.setOnClickListener(v->addText());rect.setOnClickListener(v->{editor.mode=EditorView.SHAPE;});undo.setOnClickListener(v->{editor.undo();});redo.setOnClickListener(v->{editor.redo();});clear.setOnClickListener(v->{editor.clearPage();});save.setOnClickListener(v->savePdf());
        prev.setOnClickListener(v->{if(pageIndex>0){editor.store(pageIndex);showPage(--pageIndex);}});next.setOnClickListener(v->{if(pageIndex<renderer.getPageCount()-1){editor.store(pageIndex);showPage(++pageIndex);}});
    }
    private TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(0xFF555555);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(4,0,4,0);return t;}
    private Button tool(String s){Button b=new Button(this);b.setText(s);b.setTextSize(11);return b;}
    private void showPage(int i){PdfRenderer.Page p=renderer.openPage(i);int w=Math.max(1,p.getWidth()*2),h=Math.max(1,p.getHeight()*2);Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);bmp.eraseColor(Color.WHITE);p.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);p.close();editor.setBitmap(bmp);pageLabel.setText("Page "+(i+1)+" / "+renderer.getPageCount());}
    private void addText(){final EditText in=new EditText(this);in.setHint("Text to add");new AlertDialog.Builder(this).setTitle("Add text").setView(in).setNegativeButton("Cancel",null).setPositiveButton("Add",(d,w)->{String s=in.getText().toString().trim();if(!s.isEmpty())editor.addText(s);}).show();}
    private void savePdf(){editor.store(pageIndex);try{PdfDocument out=new PdfDocument();for(int i=0;i<renderer.getPageCount();i++){PdfRenderer.Page p=renderer.openPage(i);int w=p.getWidth()*2,h=p.getHeight()*2;Bitmap bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);bmp.eraseColor(Color.WHITE);p.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);p.close();Canvas c=new Canvas(bmp);editor.drawStored(c,i,w,h);PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(w,h,i+1).create();PdfDocument.Page pg=out.startPage(info);pg.getCanvas().drawBitmap(bmp,0,0,null);out.finishPage(pg);bmp.recycle();}File f=new File(getCacheDir(),"HamaraNotes_Designed_"+System.currentTimeMillis()+".pdf");FileOutputStream fos=new FileOutputStream(f);out.writeTo(fos);fos.close();out.close();Intent r=new Intent();r.setData(androidx.core.content.FileProvider.getUriForFile(this,"com.hamaranotes.app.fileprovider",f));r.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);r.putExtra("name",f.getName());setResult(RESULT_OK,r);toast("Designed PDF saved");finish();}catch(Exception e){toast("Could not save PDF: "+e.getMessage());}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){try{if(renderer!=null)renderer.close();if(pfd!=null)pfd.close();}catch(Exception ignored){}super.onDestroy();}

    private class EditorView extends View{
        static final int PEN=0,HIGHLIGHT=1,SHAPE=2;int mode=PEN,color=0xFF6750A4;float width=6f;Bitmap bitmap;Path current;float sx,sy;ArrayList<Item> items=new ArrayList<>(), redo=new ArrayList<>();Map<Integer,ArrayList<Item>> pages=new HashMap<>();
        EditorView(){super(EditPdfActivity.this);setBackgroundColor(0xFFE8E5ED);}
        void setBitmap(Bitmap b){bitmap=b;items=pages.getOrDefault(pageIndex,new ArrayList<>());redo.clear();invalidate();}
        void snapshot(){redo.clear();}
        void store(int i){pages.put(i,new ArrayList<>(items));}
        void clearPage(){snapshot();items.clear();invalidate();}
        void undo(){if(items.isEmpty())return;redo.add(items.remove(items.size()-1));invalidate();}
        void redo(){if(redo.isEmpty())return;items.add(redo.remove(redo.size()-1));invalidate();}
        void addText(String s){Paint p=paint();p.setTextSize(46);items.add(new TextItem(s,getWidth()/2f,getHeight()/2f,p));invalidate();}
        Paint paint(){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStrokeWidth(width);return p;}
        @Override protected void onDraw(Canvas c){super.onDraw(c);if(bitmap==null)return;float s=Math.min(getWidth()/(float)bitmap.getWidth(),getHeight()/(float)bitmap.getHeight());float ox=(getWidth()-bitmap.getWidth()*s)/2,oy=(getHeight()-bitmap.getHeight()*s)/2;c.drawBitmap(bitmap,null,new RectF(ox,oy,ox+bitmap.getWidth()*s,oy+bitmap.getHeight()*s),null);for(Item it:items)it.draw(c);}
        @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX(),y=e.getY();if(e.getAction()==MotionEvent.ACTION_DOWN){sx=x;sy=y;if(mode==PEN||mode==HIGHLIGHT){current=new Path();current.moveTo(x,y);Paint p=paint();if(mode==HIGHLIGHT){p.setColor((color&0x00FFFFFF)|0x55000000);p.setStrokeWidth(Math.max(18,width*3));}items.add(new StrokeItem(current,p));}return true;}if(e.getAction()==MotionEvent.ACTION_MOVE&&current!=null){current.lineTo(x,y);invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP){if(mode==SHAPE){Paint p=paint();items.add(new RectItem(new RectF(sx,sy,x,y),p));}current=null;invalidate();return true;}return true;}
        void drawStored(Canvas c,int page,int w,int h){float sx=w/(float)Math.max(1,getWidth()),sy=h/(float)Math.max(1,getHeight());c.save();c.scale(sx,sy);ArrayList<Item> a=pages.get(page);if(a!=null)for(Item it:a)it.draw(c);c.restore();}
    }
    private abstract static class Item{abstract void draw(Canvas c);}
    private static class StrokeItem extends Item{Path p;Paint paint;StrokeItem(Path p,Paint q){this.p=p;paint=q;}void draw(Canvas c){c.drawPath(p,paint);}}
    private static class RectItem extends Item{RectF r;Paint p;RectItem(RectF r,Paint p){this.r=r;this.p=p;}void draw(Canvas c){c.drawRect(r,p);}}
    private static class TextItem extends Item{String s;float x,y;Paint p;TextItem(String s,float x,float y,Paint p){this.s=s;this.x=x;this.y=y;this.p=p;p.setStyle(Paint.Style.FILL);}void draw(Canvas c){c.drawText(s,x,y,p);}}
}

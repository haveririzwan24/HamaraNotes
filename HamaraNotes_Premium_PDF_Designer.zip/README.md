# Hamara Notes — Android starter project

This project wraps the supplied Hamara Notes HTML app in a native Android WebView container.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone or use an emulator.
4. Run the `app` configuration.
5. For Play Store, use **Build > Generate Signed Bundle / APK > Android App Bundle** and create a signed `.aab`.

The notes data is stored by the HTML app in browser localStorage, so it remains local to the app installation.
